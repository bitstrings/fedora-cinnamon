
```
 * muffin version (muffin --version or 'dpkg --list | grep libmuffin0' for Mint/Ubuntu)
 * Distribution - (Mint 17.2, Arch, Fedora 25, etc...)
 * Graphics hardware *and* driver used
 * 32 or 64 bit
 ```

**Issue**



**Steps to reproduce**



**Expected behaviour**



**Other information**
